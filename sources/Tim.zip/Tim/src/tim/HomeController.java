/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tim;

import com.jfoenix.controls.JFXButton;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebEvent;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

/**
 *
 * @author COMPUMAGIC
 */
public class HomeController implements Initializable {
    
    @FXML
    private AnchorPane dashboard;
    @FXML
    private LineChart<?, ?> line;
    @FXML
    private PieChart pie;
    @FXML
    private BarChart<String,Number> bar;    
    NumberAxis yAxis;
    CategoryAxis xAxis;
    @FXML
    private JFXButton dash;
    @FXML
    private JFXButton user;
    @FXML
    private JFXButton table;
    @FXML
    private JFXButton graph;
    @FXML
    private JFXButton icon;
    @FXML
    private JFXButton map;
    @FXML
    private JFXButton notification;
    @FXML
    private Pane pane_settings;
    @FXML
    private FontAwesomeIconView arrow;
    @FXML
    private ImageView background;
    @FXML
    private Pane side_pane;
    @FXML
    private Pane top_pane;
    @FXML
    private Pane dropdown_pane;
    @FXML
    private AnchorPane user_pane;
    @FXML
    private AnchorPane notification_pane;
    @FXML
    private AnchorPane icon_pane;
    @FXML
    private AnchorPane map_pane;
    @FXML
    private WebView web=new WebView();
    @FXML
    private Label title_txt;
 
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        //Line Chart
        XYChart.Series series1 = new XYChart.Series();
        series1.setName("Open");
        
        series1.getData().add(new XYChart.Data("9:00AM", 300));
        series1.getData().add(new XYChart.Data("12:00AM", 400));
        series1.getData().add(new XYChart.Data("3:00PM", 500));
        series1.getData().add(new XYChart.Data("6:00PM", 500));
        series1.getData().add(new XYChart.Data("9:00PM", 600));
        series1.getData().add(new XYChart.Data("12:00PM", 600));
        series1.getData().add(new XYChart.Data("3:00AM", 700));
        series1.getData().add(new XYChart.Data("6:00AM", 700));
        
        
        XYChart.Series series2 = new XYChart.Series();
        series2.setName("Click");
        series2.getData().add(new XYChart.Data("9:00AM", 50));
        series2.getData().add(new XYChart.Data("12:00AM", 100));
        series2.getData().add(new XYChart.Data("3:00PM", 150));
        series2.getData().add(new XYChart.Data("6:00PM", 150));
        series2.getData().add(new XYChart.Data("9:00PM", 250));
        series2.getData().add(new XYChart.Data("12:00PM", 300));
        series2.getData().add(new XYChart.Data("3:00AM", 350));
        series2.getData().add(new XYChart.Data("6:00AM", 400));
        
        XYChart.Series series3 = new XYChart.Series();
        series3.setName("Click Second Time");
        series3.getData().add(new XYChart.Data("9:00AM", 0));
        series3.getData().add(new XYChart.Data("12:00AM", 100));
        series3.getData().add(new XYChart.Data("3:00PM", 50));
        series3.getData().add(new XYChart.Data("6:00PM", 100));
        series3.getData().add(new XYChart.Data("9:00PM", 200));
        series3.getData().add(new XYChart.Data("12:00PM", 300));
        series3.getData().add(new XYChart.Data("3:00AM", 300));
        series3.getData().add(new XYChart.Data("6:00AM", 350));
        
        line.getData().addAll(series1, series2, series3);
        
        //Pie Chart
        ObservableList<PieChart.Data> pieChartData =
                FXCollections.observableArrayList(
                new PieChart.Data("Open", 40),
                new PieChart.Data("Bounce", 20),
                new PieChart.Data("Unsubscribe", 40));
  
        pie.setData(pieChartData);
        
        //Bar Chart
          yAxis=new NumberAxis();
          xAxis=new CategoryAxis();
    
        bar.setTitle("Country Summary");
        xAxis.setLabel("Country");       
        yAxis.setLabel("Value");
 
        XYChart.Series<String, Number> serie1 = new XYChart.Series();
        serie1.setName("Tesla Model S");       
        serie1.getData().add(new XYChart.Data("Jan", 550));
        serie1.getData().add(new XYChart.Data("Feb", 450));
        serie1.getData().add(new XYChart.Data("Mar", 320));
        serie1.getData().add(new XYChart.Data("Apr", 780));
        serie1.getData().add(new XYChart.Data("Mai", 550)); 
        serie1.getData().add(new XYChart.Data("Jun", 450)); 
        serie1.getData().add(new XYChart.Data("Jul", 320)); 
        serie1.getData().add(new XYChart.Data("Aug", 420)); 
        serie1.getData().add(new XYChart.Data("Sep", 560)); 
        serie1.getData().add(new XYChart.Data("Oct", 600)); 
        serie1.getData().add(new XYChart.Data("Nov", 750)); 
        serie1.getData().add(new XYChart.Data("Dec", 890)); 
        
        XYChart.Series<String, Number> serie2 = new XYChart.Series();
        serie2.setName("BMW 5 Series");
        serie1.getData().add(new XYChart.Data("Jan", 400));
        serie2.getData().add(new XYChart.Data("Feb", 230));
        serie2.getData().add(new XYChart.Data("Mar", 290));
        serie2.getData().add(new XYChart.Data("Apr", 590));
        serie2.getData().add(new XYChart.Data("Mai", 450)); 
        serie2.getData().add(new XYChart.Data("Jun", 350)); 
        serie2.getData().add(new XYChart.Data("Jul", 300)); 
        serie2.getData().add(new XYChart.Data("Aug", 320)); 
        serie2.getData().add(new XYChart.Data("Sep", 360)); 
        serie2.getData().add(new XYChart.Data("Oct", 500)); 
        serie2.getData().add(new XYChart.Data("Nov", 550)); 
        serie2.getData().add(new XYChart.Data("Dec", 890));   
        
         
        
        bar.getData().addAll(serie1, serie2);
    }    

    @FXML
    private void dash_exit(MouseEvent event) {
        dash.setStyle("-fx-background-color: #3E3E3E;");
        dash.setOpacity(0.7);
    }

    @FXML
    private void dash_enter(MouseEvent event) {
        dash.setStyle("-fx-background-color: #6C6C6C;");
    }

    @FXML
    private void user_exit(MouseEvent event) {
        user.setStyle("-fx-background-color: #3E3E3E;");
        user.setOpacity(0.7);
    }

    @FXML
    private void user_enter(MouseEvent event) {
        user.setStyle("-fx-background-color: #6C6C6C;");
    }

    @FXML
    private void table_exit(MouseEvent event) {
        table.setStyle("-fx-background-color: #3E3E3E;");
        table.setOpacity(0.7);
    }

    @FXML
    private void table_enter(MouseEvent event) {
        table.setStyle("-fx-background-color: #6C6C6C;");
    }

    @FXML
    private void graph_exit(MouseEvent event) {
        graph.setStyle("-fx-background-color: #3E3E3E;");
        graph.setOpacity(0.7);
    }

    @FXML
    private void graph_enter(MouseEvent event) {
        graph.setStyle("-fx-background-color: #6C6C6C;");
    }

    @FXML
    private void icon_exit(MouseEvent event) {
        icon.setStyle("-fx-background-color: #3E3E3E;");
        icon.setOpacity(0.7);
    }

    @FXML
    private void icon_enter(MouseEvent event) {
        icon.setStyle("-fx-background-color: #6C6C6C;");
    }

    @FXML
    private void map_exit(MouseEvent event) {
        map.setStyle("-fx-background-color: #3E3E3E;");
        map.setOpacity(0.7);
    }

    @FXML
    private void map_enter(MouseEvent event) {
        map.setStyle("-fx-background-color: #6C6C6C;");
    }

    @FXML
    private void notification_exit(MouseEvent event) {
        notification.setStyle("-fx-background-color: #3E3E3E;");
        notification.setOpacity(0.7);
    }

    @FXML
    private void notification_enter(MouseEvent event) {
        notification.setStyle("-fx-background-color: #6C6C6C;");
    }

    @FXML
    private void settings(MouseEvent event) {
        if(pane_settings.isVisible()){
            pane_settings.setVisible(false);
            arrow.setVisible(false);
        }else{
            pane_settings.setVisible(true);
            arrow.setVisible(true);
        }
    }

    @FXML
    private void pic_1(MouseEvent event) {
        background.setImage(new Image("Img/sidebar-3.jpg"));
    }

    @FXML
    private void pic_2(MouseEvent event) {
        background.setImage(new Image("Img/sidebar-1.jpg"));
    }

    @FXML
    private void pic_3(MouseEvent event) {
        background.setImage(new Image("Img/sidebar-2.jpg"));
    }

    @FXML
    private void pic_4(MouseEvent event) {
        background.setImage(new Image("Img/sidebar-5.jpg"));
    }

    @FXML
    private void color_1(MouseEvent event) {
        side_pane.setStyle("-fx-background-color: #777777;");
        top_pane.setStyle("-fx-background-color: #777777");
        side_pane.setOpacity(0.8);
        top_pane.setOpacity(0.75);
    }

    @FXML
    private void color_2(MouseEvent event) {
        side_pane.setStyle("-fx-background-color: #1fc6ea;");
        top_pane.setStyle("-fx-background-color: #1fc6ea");
        side_pane.setOpacity(0.8);
        top_pane.setOpacity(0.75);
    }

    @FXML
    private void color_3(MouseEvent event) {
        side_pane.setStyle("-fx-background-color: #87cb16;");
        top_pane.setStyle("-fx-background-color: #87cb16");
        side_pane.setOpacity(0.8);
        top_pane.setOpacity(0.75);
    }

    @FXML
    private void color_4(MouseEvent event) {
        side_pane.setStyle("-fx-background-color: #ffa534;");
        top_pane.setStyle("-fx-background-color: #ffa534");
        side_pane.setOpacity(0.8);
        top_pane.setOpacity(0.75);
    }

    @FXML
    private void color_5(MouseEvent event) {
        side_pane.setStyle("-fx-background-color: #9368e9;");
        top_pane.setStyle("-fx-background-color: #9368e9");
        side_pane.setOpacity(0.8);
        top_pane.setOpacity(0.75);
    }

    @FXML
    private void dropdown(MouseEvent event) {
        if(dropdown_pane.isVisible()){
            dropdown_pane.setVisible(false);
        }else{
            dropdown_pane.setVisible(true);
        }
    }

    @FXML
    private void dashBorad_pane(ActionEvent event) {
        dashboard.setVisible(true);
        user_pane.setVisible(false);
        notification_pane.setVisible(false);
        icon_pane.setVisible(false);
        map_pane.setVisible(false);
        title_txt.setText("Dashboard");
    }

    @FXML
    private void userName_pane(ActionEvent event) {
        dashboard.setVisible(false);
        user_pane.setVisible(true);
        notification_pane.setVisible(false);
        icon_pane.setVisible(false);
        map_pane.setVisible(false);
        title_txt.setText("User Name");
    }

    @FXML
    private void notification_btn(MouseEvent event) {
        dashboard.setVisible(false);
        user_pane.setVisible(false);
        notification_pane.setVisible(true);
        icon_pane.setVisible(false);
        map_pane.setVisible(false);
        title_txt.setText("Notification");
    }

    @FXML
    private void icon_btn(ActionEvent event) {
        dashboard.setVisible(false);
        user_pane.setVisible(false);
        notification_pane.setVisible(false);
        icon_pane.setVisible(true);
        map_pane.setVisible(false);
        title_txt.setText("Icons");
    }

    @FXML
    private void map_button(ActionEvent event) {
        dashboard.setVisible(false);
        user_pane.setVisible(false);
        notification_pane.setVisible(false);
        icon_pane.setVisible(false);
        map_pane.setVisible(true);
        title_txt.setText("Map");
        
        myMap map=new myMap();
   
    }


    class myMap extends Pane{
        
        WebEngine engine;
        public myMap(){
            engine=web.getEngine();
            URL url=getClass().getResource("map.html");
            engine.load(url.toExternalForm());
        }
    }
  

   
  
}
